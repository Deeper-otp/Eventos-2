﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio_de_Eventos_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            comboBox1.Items.Add("Azul");
            comboBox1.Items.Add("Amarillo");
            comboBox1.Items.Add("Rojo");
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int Colores = comboBox1.SelectedIndex;

            if(Colores == 0)
            {

                BackColor = Color.Blue;

            }else if(Colores == 1)
            {
                BackColor = Color.Yellow;
            }
            else
            {
                BackColor = Color.Red;
            }
        }
    }
}
